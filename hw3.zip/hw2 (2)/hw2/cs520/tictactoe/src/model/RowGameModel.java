//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package model;

import java.util.Stack;

public class RowGameModel {
    public static final String GAME_END_NOWINNER = "Game ends in a draw";
    public RowBlockModel[][] blocksData = new RowBlockModel[3][3];
    private Player player;
    public int movesLeft;
    private String finalResult;
    public Stack<RowBlockModel> undoStack;

    public RowGameModel() {
        this.player = RowGameModel.Player.PLAYER_0;
        this.movesLeft = 9;
        this.finalResult = null;
        this.undoStack = new Stack();

        for(int row = 0; row < 3; ++row) {
            for(int col = 0; col < 3; ++col) {
                this.blocksData[row][col] = new RowBlockModel(this);
            }
        }

    }

    public void addHistory(RowBlockModel block) {
        this.undoStack.push(block);
    }

    public Player getPlayer() {
        return this.player;
    }

    public void setPlayer(Player player) {
        if (player == null && !player.equals("1") && !player.equals("2")) {
            throw new IllegalArgumentException("Player cannot be null or other than 1 or 2.");
        } else {
            this.player = player;
        }
    }

    public int getMovesLeft() {
        return this.movesLeft;
    }

    public void setMovesLeft() {
        this.movesLeft = this.movesLeft;
    }

    public String getFinalResult() {
        return this.finalResult;
    }

    public void setFinalResult(String finalResult) {
        this.finalResult = finalResult;
    }

    public static enum Player {
        PLAYER_0(1),
        PLAYER_1(2);

        public static final String label = "PLAYER";
        private int num;

        private Player(int num) {
            this.num = num;
        }

        private String getLabel() {
            return "PLAYER" + this.num;
        }
    }
}
