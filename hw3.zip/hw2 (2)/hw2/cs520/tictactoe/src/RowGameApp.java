//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import controller.RowGameController;

public class RowGameApp {
    public RowGameApp() {
    }

    public static void main(String[] args) {
        RowGameController game = new RowGameController();
        game.gameView.gui.setVisible(true);
    }
}
