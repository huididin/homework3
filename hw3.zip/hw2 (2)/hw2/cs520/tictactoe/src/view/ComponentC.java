//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package view;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import model.RowGameModel;
import model.RowGameModel.Player;

public class ComponentC implements View {
    public JTextArea playerturn = new JTextArea();

    public ComponentC(JPanel messages) {
        messages.add(this.playerturn);
        this.playerturn.setText("Player 1 to play 'X'");
        this.playerturn.setEditable(false);
    }

    public boolean isDouble(int a) {
        return a % 2 != 1;
    }

    public void update(RowGameModel model) {
        if (model.getFinalResult() != null) {
            this.playerturn.setText(model.getFinalResult());
        } else if (this.isDouble(model.getMovesLeft())) {
            this.playerturn.setText("'O':" + Player.PLAYER_1);
        } else {
            this.playerturn.setText("'O':" + Player.PLAYER_0);
        }

    }
}
