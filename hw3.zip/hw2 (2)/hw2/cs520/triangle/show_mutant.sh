#!/bin/sh

diff --unified=0 src/triangle/Triangle.java .mutated/mutants/$1/triangle/Triangle.java
